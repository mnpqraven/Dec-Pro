% Aufgabe 8a)

max(X,Y,M) :- M is X, X >= Y.

max(X,Y,M) :- M is Y, Y >= X.

% Mit pattern matching, X falls X >= Y.
% Mit pattern matching, Y falls Y >= X. 
% max(X,Y,X) :- X >= Y.
% max(X,Y,Y) :- Y >= X.

% Aufgabe 8b)

list_length([], 0).
list_length([_|Xs], L) :- list_length(Xs, N), L is N+1.

longer(L1, L2) :- list_length(L1, X), list_length(L2, Y), X >= Y.

% Aufgabe 8c)

maxl([],0).
maxl([X|Xs], M) :- maxl(Xs, Max), X > Max, M is X.
maxl([X|Xs], M) :- maxl(Xs, Max), X =< Max, M is Max.

% ?- maxl([1,2,3,88,4], RESULT).
% Aufgabe 8d)

zip([], [], []).
zip([X|Xs], [Y|Ys], [[X,Y]|Zs]) :- zip(Xs,Ys,Zs).
